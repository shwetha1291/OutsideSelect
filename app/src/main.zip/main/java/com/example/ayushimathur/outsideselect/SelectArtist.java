package com.example.ayushimathur.outsideselect;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.PorterDuffXfermode;
import android.graphics.PorterDuff.Mode;
import android.widget.TextView;

import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;

public class SelectArtist extends AppCompatActivity {

    ArrayList<Integer> songlist;
    MediaPlayer player;
    int numTaps = 0;
    int songplaying=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_artist);
        final ImageView btnplay=(ImageView) findViewById(R.id.btnplay);
        ImageView btnskip=(ImageView) findViewById(R.id.btnskip);

        //

        InputStream inputStream = getResources().openRawResource(R.raw.artistdata);
        CSVFile csvFile = new CSVFile(inputStream);
        final ArrayList<Artist> artistList = new ArrayList<Artist>(csvFile.read());
        for (Artist a : artistList) {

        }

        songlist=new ArrayList<>();

        //iterate through list of files in raw
        Field[] fields=R.raw.class.getFields();
        for(int ct=0;ct<fields.length;ct++){
            songlist.add(R.raw.down);
            songlist.add(R.raw.marianhill);
            songlist.add(R.raw.whitney);
        }


        btnskip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                numTaps=0;
                songplaying++;
                player.stop();
                btnplay.callOnClick();
            }
        });

        btnplay.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                numTaps ++;
                if(numTaps < 2) {
                    player=MediaPlayer.create(SelectArtist.this,songlist.get(songplaying));
                    Artist a=artistList.get(songplaying);
                    TextView artname=(TextView)findViewById(R.id.artistName);
                    artname.setText(a.getName());
                    ImageView imgv=(ImageView)findViewById(R.id.artistphoto);
                    imgv.setImageResource(R.mipmap.art);
                    player.setLooping(true);
                    player.start();
                    //conver to pause
                }
                if(numTaps%2 == 0) {
                    player.pause();
                    //cont to start
                }
                if(numTaps%2 != 0 ){
                    player.start();
                    //convert to start
                }
            }
        });


        ImageView img1=(ImageView) findViewById(R.id.artistphoto);
        Bitmap bm = BitmapFactory.decodeResource(getResources(),
                R.drawable.artist_photo);
        Bitmap conv_bm = getRoundedBitmap(bm);
        img1.setImageBitmap(conv_bm);


    }

    public static Bitmap getRoundedBitmap(Bitmap bitmap)
    {
        final Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        final Canvas canvas = new Canvas(output);

        final int color = Color.RED;
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
        final RectF rectF = new RectF(rect);

        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        canvas.drawOval(rectF, paint);
        paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);

        bitmap.recycle();

        return output;
    }

}





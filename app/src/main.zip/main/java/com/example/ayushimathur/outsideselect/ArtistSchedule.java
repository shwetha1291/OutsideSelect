package com.example.ayushimathur.outsideselect;

/**
 * Created by ayushimathur on 7/23/16.
 */
public class ArtistSchedule {
    public ArtistSchedule() {}



    /* Inner class that defines the table contents */
    public static abstract class FeedEntry  {
        public static final String TABLE_NAME = "ArtistSchedule";
        public static final String NAME = "name";
        public static final String TIME = "title";
        public static final String LOCATION = "location";

    }
}
